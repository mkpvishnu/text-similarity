# text-Comparison

TextCompare is a Python library for comparing and analyzing text similarity. It provides various metrics and pipelines for text comparison tasks.
